<div class="footer" style="text-align: center; position: relative; bottom: -421px; width: 100%;">
    <p>&copy; 2025 Product Management System. All rights reserved.</p>
</div>
</body>
</html>
